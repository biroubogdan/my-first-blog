from django.shortcuts import render


# Create your views here.
from django.views.generic.list import ListView

from blog.models import Post


def posts(request):
    context = {'posts': Post.objects.all()}
    return render(request, 'posts.html', context=context)


class PostListView(ListView):
    template_name = 'posts.html'
    model = Post
    context_object_name = 'posts'
